/**
 * @FileName: NscsAllData.java
 * @creator zhaohanyang
 * @date Dec 28, 2020
 * @editor
 * @Description: 
 * @version V1.0
 */
package han.easyExcel;

import java.util.List;

import lombok.Data;

/**
 * @ClassName: NscsAllData
 * @Description: 
 * @author zhaohanyang
 * @date Dec 28, 2020
 * @version V1.0
 */
@Data
public class NscsAllData {
	private List<NscsListData> a;
	private String jgmc;
}
